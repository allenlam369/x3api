package allen.wqplis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import allen.wqplis.model.RiverLatest;

public interface RiverLatestRepository extends JpaRepository<RiverLatest, String> {

}
