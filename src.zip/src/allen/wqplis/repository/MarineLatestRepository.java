package allen.wqplis.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import allen.wqplis.model.MarineLatest;

public interface MarineLatestRepository extends JpaRepository<MarineLatest, String>{

}
